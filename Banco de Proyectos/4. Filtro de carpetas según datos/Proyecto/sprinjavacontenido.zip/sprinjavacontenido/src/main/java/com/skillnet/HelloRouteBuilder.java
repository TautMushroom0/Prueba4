package com.skillnet;
		
import java.io.File;

import javax.xml.bind.JAXB;
import org.apache.camel.converter.jaxp.XmlConverter;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JaxbDataFormat;
import org.apache.camel.spi.DataFormat;
		
public class HelloRouteBuilder extends RouteBuilder {
		
	 
		
	

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub
		
		
		//Toma la ruta y trae todos los archivos en la carpeta "in"
		// El noop=true es para indicar que unicamente me lo copie y no lo mueva.
		from("file:in?noop=true")
		//Se le indica la funcion transformar y se le dan los parametros,
		//diciendo que todas las letras ñ cambielas por n.
		//este es sensible a las minusculas y mayusculas.
		.transform(body().regexReplaceAll("ñ", "n"))
		// Indico la ubicación a donde quiere que llegue el archivo transformado.
		.to("file:out/");  
	    
	
		
	}
	
		

}

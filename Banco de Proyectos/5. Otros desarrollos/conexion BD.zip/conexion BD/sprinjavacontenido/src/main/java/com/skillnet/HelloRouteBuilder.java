package com.skillnet;
		
import org.apache.camel.builder.RouteBuilder;
import java.sql.*;

public class HelloRouteBuilder extends RouteBuilder {
				
	
	
	
	//Connection co = "";

	@Override
	public void configure() throws Exception {
		// TODO Auto-generated method stub		
		
		//from("file:in?noop=true")
		//.to("file:out?FileName=salida.docx&fileExist=Append");   //&fileExist=Append
		
		//from("file:in?noop=true")
        //.transform().xquery("FileName=Salida.pdf")
		
        //.to("file:out?fileExist=Append");
		
		from("file:start")
        .to("xslt:book-param.xslt");
									
	}
	 
	
		
	

}
